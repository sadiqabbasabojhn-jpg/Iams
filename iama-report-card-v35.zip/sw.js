// IAMA portal service worker.
//
// It keeps the PORTAL PROGRAM (the page and its libraries) on the phone so the portal still
// opens after a refresh while there is no data/internet. It never stores school records:
// students, fees, results etc. live in Firebase and in the app's own local copy, and every
// request to Firebase / Paystack / EmailJS goes straight to the network.
//
// Updates: the page is always fetched from the network first. If the connection is slow the
// saved copy is shown at once, BUT the download carries on in the background and replaces the
// saved copy; the portal then shows "A new version is ready - Update now".
const VER = 'iama-shell-v35';
const PAGES = ['index.html', 'manifest.json'];
const LIBS = [
  'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js',
  'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js'
];
// Static, version-pinned libraries and fonts only.
const STATIC_HOSTS = /^(cdnjs\.cloudflare\.com|cdn\.jsdelivr\.net|www\.gstatic\.com|fonts\.googleapis\.com|fonts\.gstatic\.com)$/;

self.addEventListener('install', function (event) {
  self.skipWaiting();
  event.waitUntil(caches.open(VER).then(function (cache) {
    return Promise.all(
      PAGES.map(function (u) { return cache.add(new Request(u, { cache: 'reload' })).catch(function () {}); })
        .concat(LIBS.map(function (u) { return cache.add(new Request(u, { mode: 'no-cors' })).catch(function () {}); }))
    );
  }));
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys()
      .then(function (keys) { return Promise.all(keys.filter(function (k) { return k !== VER; }).map(function (k) { return caches.delete(k); })); })
      .then(function () { return self.clients.claim(); })
  );
});

function tellClients() {
  return self.clients.matchAll({ type: 'window' }).then(function (cs) {
    cs.forEach(function (c) { c.postMessage({ type: 'iama-update' }); });
  });
}
// Saves the fresh page; resolves true when it is different from the copy that was saved before.
function saveFresh(cache, req, copy, isIndex) {
  const key = isIndex ? 'index.html' : req;
  return cache.match(key).then(function (old) {
    const puts = [cache.put(req, copy.clone())];
    if (isIndex) puts.push(cache.put('index.html', copy.clone()));
    if (!old) return Promise.all(puts).then(function () { return false; });
    return Promise.all([old.clone().text(), copy.clone().text(), Promise.all(puts)]).then(function (r) { return r[0] !== r[1]; });
  }).catch(function () { return false; });
}
// Shown ONLY when the phone has no saved copy of the portal yet AND the network fails.
// (Before, this case ended in Chrome's own \"This site can't be reached - ERR_FAILED\" page.)
function offlinePage() {
  const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>IAMA portal</title>'
    + '<style>body{font-family:Arial,sans-serif;background:#f4f2ea;color:#201C14;margin:0;padding:24px;text-align:center}'
    + '.b{max-width:420px;margin:60px auto;background:#fff;border-radius:14px;padding:24px;box-shadow:0 2px 12px rgba(0,0,0,.12)}'
    + 'h1{font-size:19px;margin:8px 0}p{font-size:14.5px;line-height:1.55;margin:8px 0}.s{font-size:12.5px;color:#6B6353}'
    + 'button{margin-top:12px;background:#3D2A9E;color:#fff;border:0;padding:11px 22px;border-radius:10px;font-weight:700;font-size:15px}</style></head>'
    + '<body><div class="b"><div style="font-size:42px">\uD83D\uDCF6</div><h1>No network right now</h1>'
    + '<p>The portal could not load because the phone has no working data or Wi-Fi. Please check your network, then try again. Your school records are safe.</p>'
    + '<p class="s">Babu network a yanzu. Ka duba data ko Wi-Fi, sannan ka sake gwadawa. Bayanan makaranta suna nan lafiya.</p>'
    + '<button onclick="location.reload()">Try again</button></div>'
    + '<script>addEventListener("online",function(){location.reload()});setTimeout(function(){location.reload()},20000);<\/script></body></html>';
  return new Response(html, { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' } });
}
function plainResponse(res) {
  if (!res.redirected) return Promise.resolve(res);
  return res.blob().then(function (b) { return new Response(b, { status: 200, statusText: 'OK', headers: res.headers }); });
}
// Pages: network first (newest portal); the saved copy is only a fallback.
function pageFirst(event, req, isIndex) {
  return caches.open(VER).then(function (cache) {
    let servedFromCache = false;
    const net = fetch(req.url, { cache: 'no-cache' }).then(function (res) {
      if (!(res && res.ok)) return res;
      // A page that came through a redirect (e.g. /index.html -> /) cannot be handed to a navigation: the
      // browser refuses it and shows "This site can't be reached - ERR_FAILED". Make it a plain response first.
      return plainResponse(res).then(function (ok) {
        saveFresh(cache, req, ok.clone(), isIndex).then(function (changed) { if (changed && servedFromCache) tellClients(); });
        return ok;
      });
    });
    event.waitUntil(net.catch(function () {}));   // keep going in the background even after a slow answer was replaced
    const slow = new Promise(function (_, rej) { setTimeout(function () { rej(new Error('slow')); }, 8000); });
    return Promise.race([net, slow]).catch(function () {
      return cache.match(req, { ignoreSearch: true })
        .then(function (hit) { return hit || (isIndex ? cache.match('index.html') : null); })
        .then(function (hit) {
          if (hit) { servedFromCache = true; return hit; }
          return net.catch(function () { return offlinePage(); });   // nothing saved yet: wait for the network; if it fails, show a calm page
        })
        .catch(function () { return offlinePage(); });
    });
  });
}
// Libraries and fonts: use the saved copy at once, refresh it quietly in the background.
function savedThenRefresh(req) {
  return caches.open(VER).then(function (cache) {
    return cache.match(req).then(function (hit) {
      const net = fetch(req).then(function (res) {
        if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
        return res;
      }).catch(function () { return null; });
      return hit || net.then(function (res) { return res || Response.error(); });
    });
  });
}

self.addEventListener('fetch', function (event) {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  const sameOrigin = url.origin === self.location.origin;
  if (req.mode === 'navigate' || (sameOrigin && /\.html?$/.test(url.pathname))) {
    event.respondWith(pageFirst(event, req, /(^|\/)(index\.html)?$/.test(url.pathname)));
    return;
  }
  if (sameOrigin || STATIC_HOSTS.test(url.hostname)) {
    event.respondWith(savedThenRefresh(req));
    return;
  }
  // Firebase, Paystack, EmailJS and anything else: straight to the network, never saved.
});
